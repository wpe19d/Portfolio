/*
 * wesley easton
 * 15 October 2017
 * 
 * User I/O Funtion declarations. 
 * 
*/

void read_data(float array[], int size);

void print_results(const float array[], int size, float mean, float median, float max, float min, float variance);

char read_sort(char choice);

void print_greeting();

