#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "card.h"
#include "deck.h"
#include "game.h"

int main()
{
    introduction();
}