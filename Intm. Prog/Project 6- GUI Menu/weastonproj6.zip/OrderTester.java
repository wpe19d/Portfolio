
public class OrderTester {

	
	public static void main(String [] args){
		
		
		OrderCalculation test1 = new OrderCalculation();
		test1.setVisible(true);
		
	}
}
