/**
 * Interface for classes.
 * 
 * 
 * @author  Wesley Easton
 * @version 1.0
 */


public interface CarbonFootprint {
	
	public double getCarbonFootprint();

}
