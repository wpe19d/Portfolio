/**
 * This class runs the Cell Phone Program
 * 
 * @author Wes's PC
 * @version 1.0
 * 
 * COP 3022 Project 3
 * File Name:  CellPhoneTester.java
 */

public class CellPhoneTester {
	
	
	public static void main(String[] args){
		
		Menu run1 = new Menu();
		
		run1.runMenu();
	}
}